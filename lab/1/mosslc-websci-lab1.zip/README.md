Web Science Development
Conrad Mossl
mosslc
Lab 1 - Twitter Feed with JSON

Thoughts:
A good introduction/recap for the start of class. I wanted to do so much more with this feed and try out more things, but my time was constrained by the learning curve for Bootstrap and a JSON of this type. For whatever reason, I was thrown off by sub lists in the JSON. Perhaps all I need is more practice. For instance, hyperlinking the list items was just out of my grasp. Also, making the to tweet on the list expand or make itself more known as with more information or CSS styling.

Suggestions:
Update the file for the Twitter feed. From what my program's spitting out at this point, most stuff if from around 2014 and a lot of the tweets and pictures are non-existant/deleted. Now granted, not having the right pictures and having to assume worst case is pretty realistic, but ya know. Also, a little more guidance to the directions would have been helpful. Such as more requirements and points that were definitely supposed to be developed. But at this point, we're kinda used to the Plotka-style of instructions with these labs so, ya know.